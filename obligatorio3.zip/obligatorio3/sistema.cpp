/*
 * sistema.cpp
 *
 *  Created on: 17 de may. de 2016
 *      Author: ernesto
 */

#include "sistema.h"

namespace std {

Sistema::Sistema() {
	// TODO Apéndice de constructor generado automáticamente

}

Sistema::~Sistema() {
	// TODO !CodeTemplates.destructorstub.tododesc!
}

string Sistema::listaOfertasLaboralesPublicadas() {
	return "Oferta1";
}

string Sistema::listaEstudiantesInscriptos(string numExpediente) {
	return "Estudiante1";
}

void Sistema::ingresaEntrevista(string numExpediente, string cedula, Date fechaEntrevista) {
}
} /* namespace std */

void std::Sistema::listaEmpresasExistentes() {
}

void std::Sistema::listaSucursales() {
}

void std::Sistema::ingresaOferta(int nro, string descripcion, string titulo,
		int salarioMax, int salarioMIn, int cantHoras, int cantPuestos,
		Date fechaInicio, Date fechaFin, Asignaturas* asigReq) {
}
bool std::Sistema::agregaALista(Asignaturas* listaAsig, string asigna) {
	return true;
}
